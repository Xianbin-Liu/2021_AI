textprogress.py : 文本处理的文件，将原文本生成为词向量矩阵
NerualNet.py：神经网络的源代码
util.py: mini-batch，adam等学习率策略文件
classification.py:分类的主文件
regression.Py: 回归预测的主文件